package ejercicio9;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Minimo entre 6 numeros
 */
import java.util.Scanner;

public class ejercicio9 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe un numero: ");
		int x=teclado.nextInt();
		System.out.println("Escribe un numero: ");
		int y=teclado.nextInt();
		System.out.println("Escribe un numero: ");
		int z=teclado.nextInt();
		int resultado=minimo(x,y);
		int resultado2=minimo(resultado,z);
		System.out.println("El minimo es: "+resultado2);
	}

	public static int minimo(int a, int b) {
		int minimo;
		if(a>b) {
			minimo= b;
		}else {
			minimo=a;
		}
		
		return minimo;
	}
}