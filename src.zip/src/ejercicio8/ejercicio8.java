package ejercicio8;

import java.util.Scanner;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Calculo de sumatorio productorio y punto medio de un numero
 */
public class ejercicio8 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe un numero");
		int num=teclado.nextInt();
		int sumatorio=suma1aN(num) , productorio=producto1aN(num);
		double terminoMedio=intermedio1aN(num);
		System.out.println("El sumatorio del numero recibido es: "+sumatorio);
		System.out.println("El productorio del numero recibido es: "+productorio);
		System.out.println("El termino medio del numero recibido es: "+terminoMedio);
		
	}
	public static int suma1aN(int n) {
		int num=0;
		for (int i= 0;i<n;i++) {
			num+=i+1;
		}
		return num;
	}
	
	public static int producto1aN(int n) {
		int num=1;
		for (int i= 0;i<n;i++) {
			num*=(i+1);
		}
		return num;
	}
	
	public static double intermedio1aN(int n) {
		double num=(1+n)/2;
		return num;
	}
	

}
