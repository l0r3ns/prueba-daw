package ejercicio4;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Mostrar el signo del numero pedido al usuario
 */
import java.util.Scanner;

public class ejercicio4 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe un numero: ");
		int num=teclado.nextInt();
		int valor = dimeSigno(num);
		System.out.println("El numero tiene signo: "+valor);

	}
	
	public static int dimeSigno(int a) {
		int signo;
		if(a>0) {
			signo = 1;
		}else if (a<0) {
			signo = -1;
		}else {
			signo =0;
		}
		return signo;
	}

}
