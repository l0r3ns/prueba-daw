package ejercicio11;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Tabla de multiplicar
 */
import java.util.Scanner;

public class ejercicio11 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe un numero: ");
		int num=teclado.nextInt();
		tablamultiplicar(num);
	}

	public static void tablamultiplicar(int a){
		for(int i=0; i<=10;i++) {
			int multiplicacion=a*i;
			System.out.println(a+" * "+i+" = "+multiplicacion);
		}
	}
}
