package ejercicio2;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Calculo de mayoria de edad de un usuario
 */
import java.util.Scanner;

public class ejercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe la edad del usuario: ");
		int edad=teclado.nextInt();
		boolean mayor=esMayorEdad(edad);
		if(mayor==true) {
			System.out.println("El usuario es mayor de edad");
		}else {
			System.out.println("El usuario es menor de edad");
		}

	}
	
	public static boolean esMayorEdad(int a) {
		boolean adulto=false;
		if (a>=18) {
			adulto=true;
		}
		return adulto;
	}

}
