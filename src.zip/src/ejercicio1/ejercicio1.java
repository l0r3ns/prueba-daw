package ejercicio1;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Multiplicacion de numeros reales
 */
import java.util.Scanner;

public class ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe un numero: ");
		double x=teclado.nextDouble();
		System.out.println("Escribe un numero: ");
		double y=teclado.nextDouble();
		double resultado=multiplica(x,y);
		System.out.println("La multiplicacion es: "+resultado);

	}
	public static double multiplica(double a, double b) {
		double resultado=a*b;
		return resultado;
	}
}
