package ejercicio5;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Pasar de millas a kilometros
 */
import java.util.Scanner;

public class ejercicio5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe cuantas millas ha recorrido: ");
		int millas=teclado.nextInt();
		double kilometros=millas_a_kilometros(millas);
		System.out.println("Ha recorrido un total de "+kilometros+" km");
	}
	public static double millas_a_kilometros(int millas) {
		double km= 1.60934 ;
		km*=millas;
		return km;
	}

}
