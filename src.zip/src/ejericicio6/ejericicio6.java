package ejericicio6;

import java.util.Scanner;
/*
 *Lorenzo Martínez Abelleira
 *17/11/2026
 *Añadir Iva a 5 precios  
 */
public class ejericicio6 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		final int limite=5;
		double num[];
		num= new double[limite];
		
		for(int i=0;i<limite;i++) {
			System.out.println("Escribe el precio del "+(i+1)+"º producto");
			num[i]=teclado.nextDouble();
		}
		
		for(int i=0;i<limite;i++) {
			num[i]=precioConIVA(num[i]);
			System.out.println("El valor del "+(i+1)+"º producto con iva es: "+num[i]);
		}

	}

	public static double precioConIVA(double precio) {
		double preciofinal = precio*1.21;
		return preciofinal;
	}
}
