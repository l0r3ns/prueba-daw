package ejercicio10;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Calcular si fecha es correcta
 * 
 */
import java.util.Scanner;

public class ejercicio10 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe el año de tu fecha: ");
		int ano=teclado.nextInt();
		System.out.println("Escribe el mes de tu fecha: ");
		int mes=teclado.nextInt();
		System.out.println("Escribe el dia de tu fecha: ");
		int dia=teclado.nextInt();

		boolean anocorrecto = anos(ano);
		boolean mescorrecto = meses(mes);
		boolean diacorrecto = dias(dia,mes);
		
		if(anocorrecto==true) {
			System.out.println("El año esta correcto");
		}else {
			System.out.println("El año esta incorrecto");
		}
		
		if(mescorrecto==true) {
			System.out.println("El mes esta correcto");
		}else {
			System.out.println("El mes esta incorrecto");
		}
		
		if(diacorrecto==true) {
			System.out.println("El dia esta correcto");
		}else {
			System.out.println("El dia esta incorrecto");
		}
		
		
	}
	public static boolean meses(int a) {
		boolean correcto;
		if(a<=12 && a>0) {
			correcto=true;
		}else {
			correcto=false;
		}
		return correcto;
	}
	public static boolean dias(int a, int mes) {
		boolean correcto;
		if(mes==2) {
			if(a<=28 && a>0) {
				correcto=true;
			}else {
				correcto=false;
			}
		}else {		
			if(a<=31 && a>0) {
				correcto=true;
			}else {
				correcto=false;
			}
		}
		return correcto;
	}
	
	public static boolean anos(int a) {
		boolean correcto;
		if(a<=9999 && a>0) {
			correcto=true;
		}else {
			correcto=false;
		}
		return correcto;
	}
	
	
	
}
