package ejercicio3;
/*
 * Lorenzo Martínez Abelleira
 * 17/11/2026
 * Calcular minimo entre dos numeros
 */
import java.util.Scanner;

public class ejercicio3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Escribe un numero: ");
		int x=teclado.nextInt();
		System.out.println("Escribe un numero: ");
		int y=teclado.nextInt();
		int resultado=minimo(x,y);
		System.out.println("El minimo es: "+resultado);
	}

	public static int minimo(int a, int b) {
		int minimo;
		if(a>b) {
			minimo= b;
		}else {
			minimo=a;
		}
		
		return minimo;
	}
}
