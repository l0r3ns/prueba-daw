package ejercicio7;
/*
 * Lorenzo Martinez Abelleira
 * 17/11/2026
 * Calculo de area y perimetro de un rectangulo
 */
import java.util.Scanner;

public class ejercicio7 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Cuanto es el ancho del rectangulo? ");
		double ancho=teclado.nextDouble();
		System.out.println("Cuanto es el alto del rectangulo? ");
		double alto=teclado.nextDouble();
		double perimetro= perimetroRectangulo(ancho,alto);
		double area= areaRectangulo(ancho,alto);
		
		System.out.println("El perimetro del rectangulo es: "+perimetro);
		System.out.println("El area del rectangulo es: "+area);

	}

	public static double perimetroRectangulo(double ancho, double alto) {
		double perimetro=(2*ancho)+(2*alto);
		return perimetro;
	}
	public static double areaRectangulo(double ancho, double alto) {
		double area=ancho*alto;
		return area;
	}
	
}
